export class Note {
  public id: number;
  public writer: string;
  public content: string;
  public date: number;
}
